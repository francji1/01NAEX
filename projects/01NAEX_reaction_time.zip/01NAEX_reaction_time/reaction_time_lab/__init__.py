__all__ = []
__version__ = "0.1.0"
__author__ = "Jiri Franc + Codex"
__credits__ = ["Jiri Franc + Codex"]
__license__ = "MIT"
__maintainer__ = "Jiri Franc"
