import csv
import random
import string
import time
from datetime import datetime
from pathlib import Path
from statistics import mean, median

import pandas as pd
import streamlit as st
import streamlit.components.v1 as components


st.set_page_config(page_title="Reaction Time Lab", layout="wide")

LOG_FILE = Path("reaction_time_measurements.csv")
TEXT_COLORS = ["#000000", "#e63946", "#1d3557", "#2a9d8f", "#ffb703", "#ff006e", "#8338ec"]
BACKGROUND_COLORS = ["#ffffff", "#f1faee", "#e3f2fd", "#f0efeb", "#fed9b7", "#ffe5ec", "#d0f4de"]

def default_rt_state() -> dict:
    return {
        "status": "idle",
        "config": None,
        "current_trial": 0,
        "results": [],
        "pending_delay": 0.0,
        "stimulus": "",
        "stimulus_start": None,
        "stimulus_walltime_ms": 0.0,
        "stimulus_nonce": 0,
        "text_color": "#000000",
        "background_color": "#ffffff",
        "logged": False,
        "feedback": None,
        "reset_input": False,
        "motion_css": "",
        "symbol_class": "static-symbol",
    }


def get_reaction_state() -> dict:
    if "rt_data" not in st.session_state:
        st.session_state.rt_data = default_rt_state()
    return st.session_state.rt_data


get_reaction_state()

st.session_state.setdefault("response_input", "")
st.session_state.setdefault("last_key_value", "")
st.session_state.setdefault("last_key_timestamp", 0.0)
st.session_state.setdefault("last_key_nonce", 0)


def start_reaction_test(config: dict) -> None:
    """Initialize the state for a brand-new session."""
    state = get_reaction_state()
    state.update(
        {
            "status": "waiting_delay",
            "config": config,
            "current_trial": 0,
            "results": [],
            "stimulus": "",
            "stimulus_start": None,
            "stimulus_walltime_ms": 0.0,
            "stimulus_nonce": 0,
            "text_color": "#000000",
            "background_color": "#ffffff",
            "logged": False,
            "feedback": None,
            "reset_input": True,
            "motion_css": "",
            "symbol_class": "static-symbol",
        }
    )
    st.session_state.last_key_value = ""
    st.session_state.last_key_timestamp = 0.0
    st.session_state.last_key_nonce = 0
    queue_next_stimulus(state)
    st.rerun()


def queue_next_stimulus(state: dict) -> None:
    cfg = state["config"]
    state["pending_delay"] = random.uniform(cfg["min_delay"], cfg["max_delay"])
    state["status"] = "waiting_delay"


def wait_for_stimulus(state: dict) -> None:
    placeholder = st.empty()
    trial_no = state["current_trial"] + 1
    total = state["config"]["repetitions"]
    placeholder.info(f"Trial {trial_no}/{total}: stay focused...")
    delay = max(0.0, state.get("pending_delay", 0.0))
    time.sleep(delay)
    placeholder.empty()
    launch_stimulus(state)


def launch_stimulus(state: dict) -> None:
    cfg = state["config"]
    if cfg["stimulus_type"] == "Letters":
        symbol = random.choice(string.ascii_uppercase)
    else:
        symbol = random.choice(string.digits)
    state["stimulus"] = symbol
    state["stimulus_start"] = time.perf_counter()
    state["stimulus_walltime_ms"] = time.time() * 1000.0
    state["stimulus_nonce"] = state.get("stimulus_nonce", 0) + 1
    state["text_color"] = (
        "#000000" if cfg["text_color_mode"] == "Black" else random.choice(TEXT_COLORS)
    )
    state["background_color"] = (
        "#ffffff"
        if cfg["background_mode"] == "White"
        else random.choice([c for c in BACKGROUND_COLORS if c.lower() != "#ffffff"])
    )
    state["status"] = "awaiting_input"
    state["feedback"] = None
    if cfg["motion"] == "Moving":
        state["motion_css"] = build_random_jump_css()
        state["symbol_class"] = "moving-symbol"
    else:
        state["motion_css"] = ""
        state["symbol_class"] = "static-symbol"


def build_random_jump_css() -> str:
    steps = 10
    duration = max(steps * 0.2, 0.2)
    positions = [(random.randint(-140, 140), random.randint(-80, 80)) for _ in range(steps)]
    anim_name = f"jump_{random.randint(0, 999999)}"
    keyframes = []
    for idx, (x, y) in enumerate(positions):
        pct = int((idx / max(steps - 1, 1)) * 100)
        keyframes.append(f"{pct}% {{ transform: translate({x}px, {y}px); }}")
    return f"""
    @keyframes {anim_name} {{
        {' '.join(keyframes)}
    }}
    .moving-symbol {{
        animation: {anim_name} {duration:.1f}s steps({steps}, end) infinite;
    }}
    """


def persist_results(config: dict, results: list[dict]) -> None:
    if not results:
        return
    if LOG_FILE.parent and not LOG_FILE.parent.exists():
        LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    headers = [
        "timestamp_utc",
        "participant",
        "stimulus_type",
        "font_size",
        "motion",
        "input_mode",
        "frame_motion",
        "shaking",
        "text_color_mode",
        "background_mode",
        "min_delay_sec",
        "max_delay_sec",
        "repetitions",
        "trial",
        "stimulus",
        "reaction_time_ms",
    ]
    needs_header = not LOG_FILE.exists()
    with LOG_FILE.open("a", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=headers)
        if needs_header:
            writer.writeheader()
        timestamp = datetime.utcnow().isoformat()
        for row in results:
            writer.writerow(
                {
                    "timestamp_utc": timestamp,
                    "participant": config["participant"],
                    "stimulus_type": config["stimulus_type"],
                    "font_size": config["font_size"],
                    "motion": config["motion"],
                    "input_mode": config["input_mode"],
                    "frame_motion": config.get("frame_motion", "Static frame" if not config.get("shaking") else "Shaking frame"),
                    "shaking": config["shaking"],
                    "text_color_mode": config["text_color_mode"],
                    "background_mode": config["background_mode"],
                    "min_delay_sec": config["min_delay"],
                    "max_delay_sec": config["max_delay"],
                    "repetitions": config["repetitions"],
                    "trial": row["trial"],
                    "stimulus": row["stimulus"],
                    "reaction_time_ms": round(row["reaction_time"] * 1000, 2),
                }
            )


def reset_session() -> None:
    st.session_state.rt_data = default_rt_state()
    st.session_state.rt_data["reset_input"] = True
    st.session_state.last_key_value = ""
    st.session_state.last_key_timestamp = 0.0
    st.session_state.last_key_nonce = 0
    st.rerun()


def render_stimulus(state: dict) -> None:
    cfg = state["config"]
    symbol = state["stimulus"]
    font_size = 42 if cfg["font_size"] == "Small" else 72
    shaking = cfg.get("shaking", False)
    motion_css = state.get("motion_css", "")
    shake_css = (
        """
        @keyframes shakeBox {
            0% { transform: translate(0px, 0px) rotate(0deg); }
            20% { transform: translate(-8px, 4px) rotate(-2deg); }
            40% { transform: translate(6px, -6px) rotate(2deg); }
            60% { transform: translate(-5px, 5px) rotate(-1deg); }
            80% { transform: translate(5px, 3px) rotate(1deg); }
            100% { transform: translate(0px, 0px) rotate(0deg); }
        }
        .stimulus-box.shake {
            animation: shakeBox 0.18s linear infinite;
        }
        """
        if shaking
        else ""
    )
    symbol_classes = ["stimulus-symbol"]
    symbol_class = state.get("symbol_class", "static-symbol")
    if symbol_class:
        symbol_classes.append(symbol_class)
    html = f"""
    <style>
    .stimulus-box {{
        display:flex;
        align-items:center;
        justify-content:center;
        width:100%;
        min-height:220px;
        border-radius:16px;
        border:2px dashed #222;
        font-size:{font_size}px;
        font-weight:700;
        color:{state["text_color"]};
        background:{state["background_color"]};
        margin-bottom:1rem;
        position:relative;
        overflow:hidden;
    }}
    .stimulus-symbol {{
        transition: none;
        display:inline-block;
    }}
    {motion_css}
    {shake_css}
    </style>
    <div class="stimulus-box{' shake' if shaking else ''}">
        <div class="{' '.join(symbol_classes)}">{symbol}</div>
    </div>
    """
    st.markdown(html, unsafe_allow_html=True)


def handle_response(response: str) -> None:
    state = get_reaction_state()
    cfg = state.get("config") or {}
    manual_mode = cfg.get("input_mode", "Text field + Enter") == "Text field + Enter"
    if state["status"] != "awaiting_input" or not cfg:
        if manual_mode:
            state["reset_input"] = True
        st.rerun()
        return
    text = response.strip()
    if not text:
        return

    candidate = text[-1]
    if cfg.get("stimulus_type", "Letters") == "Letters":
        candidate = candidate.upper()
    target = state["stimulus"]
    if manual_mode:
        state["reset_input"] = True
    if candidate == target:
        elapsed = time.perf_counter() - state["stimulus_start"]
        state["results"].append(
            {"trial": state["current_trial"] + 1, "stimulus": target, "reaction_time": elapsed}
        )
        state["current_trial"] += 1
        state["feedback"] = ("success", f"Correct! Reaction time {elapsed * 1000:.1f} ms")
        repetitions = cfg.get("repetitions", len(state["results"]))
        if state["current_trial"] >= repetitions:
            state["status"] = "finished"
            state["stimulus"] = ""
            if not state["logged"]:
                persist_results(cfg, state["results"])
                state["logged"] = True
            st.rerun()
        else:
            queue_next_stimulus(state)
            st.rerun()
    else:
        state["feedback"] = (
            "error",
            f"Wrong key ({candidate}). Expected {target}. The timer keeps running.",
        )
        st.rerun()


def keyboard_capture_widget(stimulus_nonce: int) -> str | None:
    component_html = """
        <style>
        #capture-box {
            border:2px dashed #1e88e5;
            padding:0.6rem 0.8rem;
            border-radius:10px;
            text-align:center;
            background:#e3f2fd;
            font-weight:600;
            user-select:none;
        }
        </style>
        <div id="capture-box" tabindex="0">
            <strong>Keyboard capture:</strong> active - keep this tab focused and just press keys (no Enter needed).
        </div>
        <script>
        const stimulusNonce = __STIMULUS_NONCE__;
        const parentDoc = window.parent.document;
        window.rtCaptureState = window.rtCaptureState || {
            handler: null,
            seq: 0,
            nonce: 0,
        };
        if (window.rtCaptureState.handler) {
            parentDoc.removeEventListener("keydown", window.rtCaptureState.handler, true);
        }
        if (window.rtCaptureState.nonce !== stimulusNonce) {
            window.rtCaptureState.nonce = stimulusNonce;
            window.rtCaptureState.seq = 0;
        }
        window.rtCaptureState.handler = (event) => {
            if (!parentDoc.hasFocus()) {
                return;
            }
            if (event.repeat) {
                return;
            }
            if (!event.key || event.key.length !== 1) {
                return;
            }
            window.rtCaptureState.seq += 1;
            Streamlit.setComponentValue({
                key: event.key,
                nonce: stimulusNonce,
                seq: window.rtCaptureState.seq
            });
            event.preventDefault();
        };
        parentDoc.addEventListener("keydown", window.rtCaptureState.handler, true);
        window.addEventListener("unload", () => {
            parentDoc.removeEventListener("keydown", window.rtCaptureState.handler, true);
        });
        setTimeout(() => {
            Streamlit.setComponentReady();
            Streamlit.setFrameHeight(85);
        }, 0);
        </script>
        """
    component_html = component_html.replace("__STIMULUS_NONCE__", str(stimulus_nonce))
    component_value = components.html(component_html, height=85)
    return component_value

st.title("Reaction Time Lab")
st.write(
    "Run controlled reaction-time measurements for visual cues and keep every trial ready "
    "for a 2k factorial design later on."
)

config_container = st.container()
with config_container:
    st.subheader("Experiment configuration")
    with st.form("config-form", clear_on_submit=False):
        participant = st.text_input("Participant name")
        col1, col2, col3 = st.columns(3)
        with col1:
            stimulus_type = st.selectbox("Stimulus set", ["Letters", "Digits"])
            font_size = st.selectbox("Font scale", ["Small", "Large"])
        with col2:
            motion = st.selectbox("Motion", ["Static", "Moving"], help="Moving means the cue jumps across the screen.")
            text_color_mode = st.selectbox("Text color", ["Black", "Random colors"])
        with col3:
            background_mode = st.selectbox("Background", ["White", "Random colors"])
            repetitions = st.number_input("Repetitions", min_value=1, max_value=200, value=10, step=1)

        col_extra1, col_extra2 = st.columns(2)
        with col_extra1:
            input_mode = st.selectbox(
                "Response mode",
                ["Text field + Enter", "Instant keyboard capture"],
                help="Use the instant capture mode to skip hitting Enter after each key.",
            )
        with col_extra2:
            frame_motion = st.selectbox(
                "Frame motion",
                ["Static frame", "Shaking frame"],
                help="Shake the whole frame to add extra distraction.",
            )
            shaking = frame_motion == "Shaking frame"

        col4, col5 = st.columns(2)
        with col4:
            min_delay = st.number_input(
                "Minimum delay before cue (seconds)", min_value=0.2, max_value=10.0, value=1.0, step=0.1, format="%.1f"
            )
        with col5:
            max_delay = st.number_input(
                "Maximum delay before cue (seconds)", min_value=0.5, max_value=12.0, value=5.0, step=0.1, format="%.1f"
            )

        submitted = st.form_submit_button("Start reaction test", use_container_width=True)

    if submitted:
        if not participant.strip():
            st.warning("Please enter the participant's name before starting.")
        elif min_delay >= max_delay:
            st.warning("The maximum delay must be greater than the minimum delay.")
        else:
            cfg = {
                "participant": participant.strip(),
                "stimulus_type": stimulus_type,
                "font_size": font_size,
                "motion": motion,
                "text_color_mode": text_color_mode,
                "background_mode": background_mode,
                "repetitions": int(repetitions),
                "input_mode": input_mode,
                "frame_motion": frame_motion,
                "shaking": shaking,
                "min_delay": float(min_delay),
                "max_delay": float(max_delay),
            }
            start_reaction_test(cfg)

st.caption(
    "Pick the response mode above: either type the cue and hit Enter, or enable instant keyboard capture and simply press keys."
)
st.divider()

state = get_reaction_state()
feedback = state.get("feedback")
if feedback:
    level, message = feedback
    if level == "success":
        st.success(message)
    elif level == "error":
        st.error(message)
    else:
        st.info(message)

if state["status"] == "idle":
    st.info(
        "Set up the factors above, hit **Start reaction test**, and keep the browser window focused. "
        "The app will insert a random delay (between your min and max values) before each cue."
    )

if state["status"] == "waiting_delay":
    wait_for_stimulus(state)

if state["status"] == "awaiting_input":
    cfg = state["config"]
    st.write(
        f"Trial {state['current_trial'] + 1} / {cfg['repetitions']}  -  "
        f"{cfg['stimulus_type']}  |  {cfg['font_size']} font  |  {cfg['motion']} text"
    )
    render_stimulus(state)
    if cfg["input_mode"] == "Instant keyboard capture":
        st.info(
            "Keyboard capture is active. Keep this browser tab focused and just press the matching key "
            "(no Enter, no clicks)."
        )
        key_event = keyboard_capture_widget(state.get("stimulus_nonce", 0))
        if key_event:
            if isinstance(key_event, dict):
                key_char = str(key_event.get("key") or "")
                nonce = int(key_event.get("nonce") or 0)
                seq = int(key_event.get("seq") or 0)
            else:
                key_char = str(key_event)
                nonce = 0
                seq = 0
            if key_char:
                current_nonce = state.get("stimulus_nonce", 0)
                if nonce != current_nonce:
                    pass
                else:
                    last_char = st.session_state.get("last_key_value", "")
                    last_seq = int(st.session_state.get("last_key_timestamp") or 0)
                    last_nonce = int(st.session_state.get("last_key_nonce") or 0)
                    if key_char == last_char and seq == last_seq and nonce == last_nonce:
                        pass
                    else:
                        st.session_state.last_key_value = key_char
                        st.session_state.last_key_timestamp = seq
                        st.session_state.last_key_nonce = nonce
                        handle_response(key_char)
    else:
        if state.get("reset_input"):
            st.session_state["response_input"] = ""
            state["reset_input"] = False
        with st.form("response-form", clear_on_submit=True):
            response = st.text_input(
                "Type the character you see and confirm with Enter",
                key="response_input",
                max_chars=1,
                help="Keep the cursor in this box during the measurement.",
            )
            submitted = st.form_submit_button("Submit response (Enter)")
        if submitted and response:
            handle_response(response)

if state["status"] == "finished" and state["results"]:
    cfg = state["config"]
    st.success("Session finished. Measurements are stored locally for your factorial analysis.")
    times_ms = [r["reaction_time"] * 1000 for r in state["results"]]
    c1, c2 = st.columns(2)
    with c1:
        st.metric("Average reaction time (ms)", f"{mean(times_ms):.1f}")
    with c2:
        st.metric("Median reaction time (ms)", f"{median(times_ms):.1f}")

    df = pd.DataFrame(
        {
            "Trial": [r["trial"] for r in state["results"]],
            "Stimulus": [r["stimulus"] for r in state["results"]],
            "Reaction time (ms)": [round(t, 2) for t in times_ms],
        }
    )
    st.dataframe(df, use_container_width=True)

    st.subheader("Session factors")
    st.json(
        {
            "participant": cfg["participant"],
            "stimulus_type": cfg["stimulus_type"],
            "font_size": cfg["font_size"],
            "motion": cfg["motion"],
            "frame_motion": cfg.get("frame_motion", "Shaking frame" if cfg["shaking"] else "Static frame"),
            "text_color_mode": cfg["text_color_mode"],
            "background_mode": cfg["background_mode"],
            "input_mode": cfg["input_mode"],
            "min_delay_sec": cfg["min_delay"],
            "max_delay_sec": cfg["max_delay"],
            "repetitions": cfg["repetitions"],
        }
    )
    st.caption(f"Results appended to `{LOG_FILE.name}` in this folder.")
    st.button("Set up another run", on_click=reset_session, use_container_width=True)

if state["status"] in {"waiting_delay", "awaiting_input"}:
    st.button("Abort session", on_click=reset_session, use_container_width=True)
